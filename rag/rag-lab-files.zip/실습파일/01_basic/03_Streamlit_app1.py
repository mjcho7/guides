import streamlit as st

st.title("간단한 챗봇")


# 터미널에서 아래 명령어 실행 
# uv run streamlit run 03_Streamlit_app1.py