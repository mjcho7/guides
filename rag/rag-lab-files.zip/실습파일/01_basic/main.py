def main():
    print("Hello from prj02!")


if __name__ == "__main__":
    main()
