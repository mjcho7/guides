import streamlit as st
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.messages import BaseMessage
from pydantic import BaseModel, Field
from typing import List
# 환경 변수 로드
from dotenv import load_dotenv
load_dotenv()

# ======================================
# 1️⃣ LangChain - 히스토리 클래스 정의
# ======================================
class InMemoryHistory(BaseChatMessageHistory, BaseModel):
    messages: List[BaseMessage] = Field(default_factory=list)
    max_length: int = 10  # 최근 메시지 10개 유지

    def add_messages(self, messages: List[BaseMessage]) -> None:
        self.messages.extend(messages)
        if len(self.messages) > self.max_length:
            self.messages = self.messages[-self.max_length:]

    def clear(self) -> None:
        self.messages = []


# ======================================
# 2️⃣ 세션별 히스토리 관리 함수
# ======================================
def get_session_history(session_id: str) -> BaseChatMessageHistory:
    # Streamlit 세션 상태에 히스토리를 저장 (끊기지 않게 유지)
    if "store" not in st.session_state:
        st.session_state.store = {}

    if session_id not in st.session_state.store:
        st.session_state.store[session_id] = InMemoryHistory()

    return st.session_state.store[session_id]


# ======================================
# 3️⃣ LangChain 구성
# ======================================
prompt = ChatPromptTemplate.from_messages([
    ("system", "당신은 {subject}에 능숙한 친절한 비서입니다."
               "주제에 맞지 않는 질문에는 '잘 모르겠습니다'라고 답변합니다."), ####### 추가
    MessagesPlaceholder(variable_name="history"),
    ("human", "{question}")
])

model = ChatOpenAI(model="gpt-4o-mini")

chain = RunnableWithMessageHistory(
    prompt | model,
    get_session_history,
    input_messages_key="question",
    history_messages_key="history"
)


# ======================================
# 4️⃣ Streamlit UI 구성
# ======================================
st.set_page_config(page_title="LangChain 챗봇", page_icon="🤖")
st.title("🤖 LangChain 기반 간단한 챗봇")

session_id = "user1"  # 간단히 고정값
subject = st.selectbox("대화 주제 선택:", ["수학", "요리", "일상", "영어"])
user_input = st.text_input("메시지를 입력하세요:")

# 대화 실행
if user_input:
    with st.spinner("생각 중..."):
        response = chain.invoke(
            {"subject": subject, "question": user_input},
            config={"configurable": {"session_id": session_id}}
        )

    # 대화 표시
    history = get_session_history(session_id)
    st.divider()
    for msg in history.messages:
        if msg.type == "human":
            st.chat_message("user").write(msg.content)
        else:
            st.chat_message("assistant").write(msg.content)

# 터미널에서 아래 명령어 실행 
# uv run streamlit run 04_Streamlit_app2.py